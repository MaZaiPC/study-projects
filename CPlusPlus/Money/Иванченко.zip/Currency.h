#pragma once
#include "stdafx.h"

class Currency
{
public:
	virtual int to_RUB() = 0;

	virtual friend istream &operator>>(istream &is, Currency &obj) = 0;
	virtual friend ostream &operator<<(ostream &os, const Currency &obj) = 0;
};

class Dollar : public Currency
{
protected:
	double bucks;
public:
	Dollar();
	Dollar(double bucks);
	~Dollar();
	virtual int to_RUB();

	virtual friend istream &operator>>(istream &is, Dollar &obj);
	virtual friend ostream &operator<<(ostream &os, const Dollar &obj);
};

class Euro : public Currency
{
protected:
	double bucks;
public:
	Euro();
	Euro(double bucks);
	~Euro();
	virtual int to_RUB();

	virtual friend istream &operator>>(istream &is, Euro &obj);
	virtual friend ostream &operator<<(ostream &os, const Euro &obj);
};
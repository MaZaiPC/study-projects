#pragma once


class Application
{
public:
	Application();
	~Application();

	void run();
	// void TestShape();
	void Polymorpha();

}; // Application




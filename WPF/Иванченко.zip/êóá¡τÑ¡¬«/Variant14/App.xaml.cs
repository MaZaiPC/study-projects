﻿using System.Windows;

namespace MaZaiPC.Variant14
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
